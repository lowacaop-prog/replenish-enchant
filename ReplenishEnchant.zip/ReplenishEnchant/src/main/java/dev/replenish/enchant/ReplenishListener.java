package dev.replenish.enchant;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.EnumMap;
import java.util.Map;

public class ReplenishListener implements Listener {

    private final ReplenishPlugin plugin;

    // Maps a fully-grown crop to the seed/replant material
    private static final Map<Material, Material> CROP_TO_SEED = new EnumMap<>(Material.class);

    static {
        CROP_TO_SEED.put(Material.WHEAT,        Material.WHEAT_SEEDS);
        CROP_TO_SEED.put(Material.CARROTS,      Material.CARROT);
        CROP_TO_SEED.put(Material.POTATOES,     Material.POTATO);
        CROP_TO_SEED.put(Material.BEETROOTS,    Material.BEETROOT_SEEDS);
        CROP_TO_SEED.put(Material.NETHER_WART,  Material.NETHER_WART);
        CROP_TO_SEED.put(Material.COCOA,        Material.COCOA_BEANS);
        CROP_TO_SEED.put(Material.PITCHER_CROP, Material.PITCHER_POD);   // 1.20+
        CROP_TO_SEED.put(Material.TORCHFLOWER_CROP, Material.TORCHFLOWER_SEEDS); // 1.20+
    }

    public ReplenishListener(ReplenishPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        Material type = block.getType();

        // Must be a crop we track
        if (!CROP_TO_SEED.containsKey(type)) return;

        // Must be fully grown
        BlockData data = block.getBlockData();
        if (data instanceof Ageable ageable) {
            if (ageable.getAge() < ageable.getMaximumAge()) return;
        }

        // Player must have Replenish on their held item
        ItemStack heldItem = player.getInventory().getItemInMainHand();
        int level = ReplenishEnchantment.getLevel(heldItem);
        if (level <= 0) return;

        // Check player has permission
        if (!player.hasPermission("replenish.use")) return;

        // Check player has a seed to consume (level I consumes, level II has 50% chance, level III never consumes)
        Material seedMaterial = CROP_TO_SEED.get(type);
        boolean consumeSeed = shouldConsumeSeed(level);

        if (consumeSeed && !hasSeed(player, seedMaterial)) return;

        // Capture location and block info before the event finishes
        Location loc = block.getLocation().clone();
        Material cropType = type;

        // Schedule replant one tick later (after drops are handled)
        new BukkitRunnable() {
            @Override
            public void run() {
                Block targetBlock = loc.getBlock();

                // Only replant if the block is now air (was actually broken)
                if (targetBlock.getType() != Material.AIR) return;

                // Consume seed from inventory if needed
                if (consumeSeed) {
                    removeSeedFromInventory(player, seedMaterial);
                }

                // Replant the crop at age 0
                targetBlock.setType(cropType);
                BlockData newData = targetBlock.getBlockData();
                if (newData instanceof Ageable ageable) {
                    ageable.setAge(0);
                    targetBlock.setBlockData(newData);
                }

                // Play a subtle replant sound
                loc.getWorld().playSound(loc, Sound.ITEM_CROP_PLANT, 0.8f, 1.2f);

                // Visual particle effect
                loc.getWorld().spawnParticle(
                    Particle.VILLAGER_HAPPY,
                    loc.clone().add(0.5, 0.5, 0.5),
                    5, 0.3, 0.3, 0.3, 0
                );
            }
        }.runTaskLater(plugin, 1L);
    }

    /**
     * Level I: always consumes seed
     * Level II: 50% chance to consume
     * Level III: never consumes
     */
    private boolean shouldConsumeSeed(int level) {
        return switch (level) {
            case 1 -> true;
            case 2 -> Math.random() < 0.5;
            default -> false; // level 3+
        };
    }

    private boolean hasSeed(Player player, Material seed) {
        return player.getInventory().contains(seed);
    }

    private void removeSeedFromInventory(Player player, Material seed) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == seed) {
                if (item.getAmount() > 1) {
                    item.setAmount(item.getAmount() - 1);
                } else {
                    player.getInventory().setItem(i, null);
                }
                return;
            }
        }
    }
}
