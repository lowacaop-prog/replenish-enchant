package dev.replenish.enchant;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class ReplenishCommand implements CommandExecutor {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("replenish.give")) {
            player.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        // Parse level (default 1)
        int level = 1;
        if (args.length > 0) {
            try {
                level = Integer.parseInt(args[0]);
                if (level < 1 || level > 3) {
                    player.sendMessage(ChatColor.RED + "Level must be between 1 and 3.");
                    return true;
                }
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "Invalid level. Usage: /replenish [1-3]");
                return true;
            }
        }

        ItemStack heldItem = player.getInventory().getItemInMainHand();
        if (heldItem.getType().isAir()) {
            player.sendMessage(ChatColor.RED + "Hold a tool or hoe to enchant it!");
            return true;
        }

        ReplenishEnchantment.applyEnchantment(heldItem, level);

        String roman = switch (level) {
            case 2 -> "II";
            case 3 -> "III";
            default -> "I";
        };

        player.sendMessage(ChatColor.GREEN + "✔ Applied " + ChatColor.GRAY + "Replenish " + roman
                + ChatColor.GREEN + " to your " + formatName(heldItem.getType().name()) + "!");
        return true;
    }

    private String formatName(String name) {
        String[] words = name.toLowerCase().replace("_", " ").split(" ");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
}
