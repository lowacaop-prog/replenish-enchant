package dev.replenish.enchant;

import org.bukkit.plugin.java.JavaPlugin;

public class ReplenishPlugin extends JavaPlugin {

    private static ReplenishPlugin instance;

    @Override
    public void onEnable() {
        instance = this;

        // Register event listener
        getServer().getPluginManager().registerEvents(new ReplenishListener(this), this);

        // Register command
        getCommand("replenish").setExecutor(new ReplenishCommand());

        getLogger().info("ReplenishEnchant enabled! Auto-replanting crops is ready.");
    }

    @Override
    public void onDisable() {
        getLogger().info("ReplenishEnchant disabled.");
    }

    public static ReplenishPlugin getInstance() {
        return instance;
    }
}
