package dev.replenish.enchant;

import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class ReplenishEnchantment {

    private static final NamespacedKey KEY = new NamespacedKey(ReplenishPlugin.getInstance(), "replenish_level");
    private static final String LORE_PREFIX = ChatColor.GRAY + "Replenish ";

    /**
     * Returns the Replenish level on an item (0 if none).
     */
    public static int getLevel(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return 0;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        Integer level = pdc.get(KEY, PersistentDataType.INTEGER);
        return level != null ? level : 0;
    }

    /**
     * Applies Replenish at the given level (1–3) to an item, adding lore.
     */
    public static ItemStack applyEnchantment(ItemStack item, int level) {
        if (item == null || level < 1 || level > 3) return item;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Store the level in persistent data
        meta.getPersistentDataContainer().set(KEY, PersistentDataType.INTEGER, level);

        // Update lore — remove any existing Replenish lore first
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.removeIf(line -> ChatColor.stripColor(line).startsWith("Replenish "));
        lore.add(0, LORE_PREFIX + toRoman(level));

        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Removes the Replenish enchantment from an item.
     */
    public static ItemStack removeEnchantment(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return item;
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().remove(KEY);

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.removeIf(line -> ChatColor.stripColor(line).startsWith("Replenish "));
        if (!lore.isEmpty()) meta.setLore(lore); else meta.setLore(null);

        item.setItemMeta(meta);
        return item;
    }

    private static String toRoman(int number) {
        return switch (number) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            default -> String.valueOf(number);
        };
    }
}
